OpenTakeoff BAS scoped takeoff snapshot

Unsigned historical approval declaration, not approval of a newer working project.
Reviewer identity is self-declared and timestamp is local/untrusted.
snapshot.json contains the exact reviewed readiness, scope, dependencies, issues, exclusions and initial seal.
takeoff.json preserves the complete original inputs, results and decision history.
sources/ contains every referenced original PDF, named by SHA-256.
Open with the BAS snapshot verifier: verify every original and replay saved calculations before trusting this declaration.
The archive alone has not rerun Python on your machine. Hashes are tamper checks, not authenticated signatures.
No project-complete, installed/as-built quantity, or engineering certification is asserted.
